require('coffee-script/register')
require('./main/startup')
